import pygame
import random
import math

pygame.init()
screen = pygame.display.set_mode((800, 600))

# Title and Icon
icon = pygame.image.load("enemy.png")
pygame.display.set_icon(icon)
pygame.display.set_caption('Space Invaders')
# background image
background = pygame.image.load("bgd.png")

# Background sound
background_sound = pygame.mixer.Sound("background.wav")
background_sound.play(-1)

# making player
playerimg = pygame.image.load('Spacecraft.png')
playerx = 370
playery = 480
playerx_change = 0
playery_change = 0

score = 0


def player(x, y):
    screen.blit(playerimg, (x, y))


def is_collision(enemyx, bulletx, enemyy, bullety):
    distance = math.sqrt(math.pow(enemyx - bulletx, 2) + math.pow(enemyy - bullety, 2))
    if distance < 32:
        return True
    else:
        return False


enemyimg = []
enemyx = []
enemyy = []
enemyx_change = []
enemyy_change = []
num_of_enemies = 4

for i in range(num_of_enemies):
    enemyimg.append(pygame.image.load('enemy.png'))
    enemyx.append(random.randint(0, 730))
    enemyy.append(random.randint(0, 200))
    enemyx_change.append(1)
    enemyy_change.append(0.5)


def enemy(x, y, i):
    screen.blit(enemyimg[i], (x, y))

    # making Bullet
    # ready state means we can't see bullet
    # fire state means we can see bullet


bulletimg = pygame.image.load('bullet.png')
bulletx = 0
bullety = 480
bulletx_change = 0
bullety_change = 20
bullet_state = "ready"

# score
score = 0
font = pygame.font.Font('freesansbold.ttf', 32)
textx = 10
texty = 10

Gameover = pygame.font.Font('freesansbold.ttf', 100)


def gameover(x, y):
    gameovertext = Gameover.render("Game Over", True, (155, 155, 0))
    screen.blit(gameovertext, (x, y))


def show_score(x, y):
    score_value = font.render("score :" + str(score), True, (155, 155, 0))
    screen.blit(score_value, (x, y))


def fire_bullet(x, y):
    global bullet_state
    bullet_state = "fire"
    screen.blit(bulletimg, (x + 16, y + 10))


# Game Loop>>>>>>>>>
# Allowing to Run the program till Quiting the Game
Running = True
# Adding Quit Function
while Running:
    screen.blit(background, (0, 0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Running = False
        # adding key movement
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                playerx_change = -6
            if event.key == pygame.K_RIGHT:
                playerx_change = 6
            if event.key == pygame.K_SPACE:
                if bullet_state == "ready":
                    pygame.mixer.Sound("shoot.wav").play()
                    bulletx = playerx
                    fire_bullet(bulletx, bullety)
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                playerx_change = 0
    # limiting boundary of space ship
    playerx = playerx + playerx_change
    if playerx >= 736:
        playerx = 736
    elif playerx <= 0:
        playerx = 0
    # limiting boundary of space ship
    for i in range(num_of_enemies):
        enemyx[i] = enemyx[i] + enemyx_change[i]
        enemyy[i] += enemyy_change[i]
        if enemyx[i] <= 0:
            enemyx_change[i] = 1
            enemyy[i] += enemyy_change[i]
        elif enemyx[i] >= 740:
            enemyx_change[i] = -1
            enemyy[i] += enemyy_change[i]
        enemy(enemyx[i], enemyy[i], i)
        collision = is_collision(enemyx[i], bulletx, enemyy[i], bullety)
        if collision:
            enemyy_change[i] += 0.2
            enemyx_change [i] += 0.1
            pygame.mixer.Sound("kill.wav").play()
            bullety = 480
            bullet_state = "ready"
            score += 1
            print(score)
            enemyx[i] = random.randint(0, 730)
            enemyy[i] = random.randint(0, 200)
        if enemyy[i] >= 480:
            for j in range(num_of_enemies):
                enemyy[j] = 2000
                gameover(120, 280)
                bullet_state = "ready "

    player(playerx, playery)
    show_score(textx, texty)
    # bullet movement
    if bullety <= 0:
        bullety = 480
        bullet_state = "ready"
    if bullet_state == "fire":
        fire_bullet(bulletx, bullety)
        bullety -= bullety_change

    pygame.display.update()
